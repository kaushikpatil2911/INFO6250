/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.neu.edu.beconnected.action;

import com.neu.edu.beconnected.pojo.User;


/**
 *
 * @author kaushikpatil
 */
public class UserAction {
    User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
    
}
